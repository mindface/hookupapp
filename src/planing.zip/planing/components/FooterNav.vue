<template>
  <footer class="footer">
    <small class="footer--copy">
      &copy; F engine
    </small>
  </footer>
</template>

<script>
export default {
  name: 'FooterNav',
  data () {
    return {
      message: "footer"
    }
  }
}
</script>

<style scoped>
</style>
