
let state = {
 loading: false,
 level_data: [],
 face_pattern_data: [],
 state_data: [],
 post_item_data: [],
}

export default state
